/******************** Med-X Institute ********************
* File Name          : System.h
* Author             : Lishen Yin
* Date First Issued  : 4/20/2012
********************************************************************************/



#ifndef __system_h
#define __system_h



/*****************private functions*******************************************************/



void System_initialization(void);
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void SPI_Configuration(void);
void Can_Configuration(void);
void Can_send(vu8 type, vu8 Idnumber, vu8 status);
void TIM_Configuration(vu32 StimPeriod);
void SysTick_Config(void);
void Delay(u32 nCount);
void Decrement_TimingDelay(void);
void CAN_start (void );
void CAN_setup (void);
void USART_Configuration(void);

/*************************************************************************/



#endif /* __system.h */
